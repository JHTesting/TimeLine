package UserInterface;

import Filtering.ContainsWord;
import logic.Event;
import logic.EventHandler;
import logic.Lecture;
import logic.WeekDays;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class UserInterface implements Runnable {

    public JFrame frame;
    public EventHandler handler;
    public JPanel mainPanel;
    private CardLayout cardLayout;


    public UserInterface(EventHandler handler) {

        this.handler = handler;
        this.cardLayout = new CardLayout();


    }

    public void run() {


        // creates the main frame
        frame = new JFrame();
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(600, 400));
        frame.setLocationRelativeTo(null);
        // located at center of screen
        frame.setTitle("TimeTable App");
        createComponents(frame.getContentPane());
        frame.pack();
        frame.setVisible(true);
    }

    private void createComponents(Container container) {

        container.setLayout(cardLayout);
        container.add(new MainPanel().createMainPanel(), "MAIN_PANEL");
        container.add(new addEventPanel().createAddEventPanel(), "ADD_PANEL");
        container.add(new filterPanel().createFilterPanel(), "FILTER_PANEL");
        container.add(new removePanel().createRemovePanel(), "REMOVAL_PANEL");

    }

    // needs changes
    class MainPanel {

        //main panel, where the timetable will be displayed

        private ArrayList<JScrollPane> weekdayPanels;
        private ArrayList<WeekDays> weekdayList;
        private JPanel weekPanel;
        private CardLayout weekPanelLayout;

        private JPanel createMainPanel() {
            mainPanel = new JPanel(new GridLayout(3, 1)); // THIS IS THE GRIDLAYOUT WE NEED TO THROW OUT ASAP
            mainPanel.add(createSelectPanel());
            mainPanel.add(createWeekPanel());
            mainPanel.add(createButtonPanel());
            weekPanelLayout.show(weekPanel, "MON_PANEL");

            return mainPanel;
        }

        private JPanel createSelectPanel() {

            // Drop down menu where the day can be selected

            JPanel selectPanel = new JPanel(new BorderLayout());


            String[] strings = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};

            JComboBox dayList = new JComboBox(strings);
            dayList.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String selectedDay = (String) dayList.getSelectedItem();
                    evaluateDaySelected(selectedDay);
                }
            });

            selectPanel.add(dayList, BorderLayout.NORTH);

            return selectPanel;
        }

        private JPanel createWeekPanel() {

            // Panel where the events for the day will be displayed

            weekPanel = new JPanel();
            weekPanelLayout = new CardLayout();
            weekPanel.setLayout(weekPanelLayout);

            createDayPanelsAndAddToList();

            return weekPanel;

        }

        private void evaluateDaySelected(String day) {

            // this method evaluates which day has been selected


            if (Objects.equals(day, "Monday")) {
                weekPanelLayout.show(weekPanel, "MON_PANEL");
            } else if (Objects.equals(day, "Tuesday")) {
                weekPanelLayout.show(weekPanel, "TUE_PANEL");
            } else if (Objects.equals(day, "Wednesday")) {
                weekPanelLayout.show(weekPanel, "WED_PANEL");
            } else if (Objects.equals(day, "Thursday")) {
                weekPanelLayout.show(weekPanel, "THU_PANEL");
            } else if (Objects.equals(day, "Friday")) {
                weekPanelLayout.show(weekPanel, "FRI_PANEL");
            } else if (Objects.equals(day, "Saturday")) {
                weekPanelLayout.show(weekPanel, "SAT_PANEL");
            } else if (Objects.equals(day, "Sunday")) {
                weekPanelLayout.show(weekPanel, "SUN_PANEL");
            }
        }


        private void createDayPanelsAndAddToList() {

            // list of panels for each day
            this.weekdayPanels = new ArrayList<>();

            // list of weekdays
            this.weekdayList = new ArrayList<>();
            weekdayList.add(WeekDays.MON);
            weekdayList.add(WeekDays.TUE);
            weekdayList.add(WeekDays.WED);
            weekdayList.add(WeekDays.THU);
            weekdayList.add(WeekDays.FRI);
            weekdayList.add(WeekDays.SAT);
            weekdayList.add(WeekDays.SUN);

            //creating a panel for each weekday
            JScrollPane mondayPanel = new WeekdayPanel("Monday", WeekDays.MON).createDayPanel();
            JScrollPane tuesdayPanel = new WeekdayPanel("Tuesday", WeekDays.TUE).createDayPanel();
            JScrollPane wednesdayPanel = new WeekdayPanel("Wednesday", WeekDays.WED).createDayPanel();
            JScrollPane thursdayPanel = new WeekdayPanel("Thursday", WeekDays.THU).createDayPanel();
            JScrollPane fridayPanel = new WeekdayPanel("Friday", WeekDays.FRI).createDayPanel();
            JScrollPane saturdayPanel = new WeekdayPanel("Saturday", WeekDays.SAT).createDayPanel();
            JScrollPane sundayPanel = new WeekdayPanel("Sunday", WeekDays.SUN).createDayPanel();

            // adding panels to created list
            weekdayPanels.add(mondayPanel);
            weekdayPanels.add(tuesdayPanel);
            weekdayPanels.add(wednesdayPanel);
            weekdayPanels.add(thursdayPanel);
            weekdayPanels.add(fridayPanel);
            weekdayPanels.add(saturdayPanel);
            weekdayPanels.add(sundayPanel);

            // adding the panels to the cardLayout manager of weekpanel
            weekPanel.add(mondayPanel, "MON_PANEL");
            weekPanel.add(tuesdayPanel, "TUE_PANEL");
            weekPanel.add(wednesdayPanel, "WED_PANEL");
            weekPanel.add(thursdayPanel, "THU_PANEL");
            weekPanel.add(fridayPanel, "FRI_PANEL");
            weekPanel.add(saturdayPanel, "SAT_PANEL");
            weekPanel.add(sundayPanel, "SUN_PANEL");
        }


        private JPanel createButtonPanel() {

            // creates a panel for the buttons at the bottom

            JPanel buttonPanel = new JPanel(new GridLayout(1, 3));
            buttonPanel.setSize(new Dimension(600, 75));
            buttonPanel.setMinimumSize(new Dimension(600, 75));
            buttonPanel.setMaximumSize(new Dimension(600, 75));

            // add button, shows "Add new event panel" when pressed
            JButton addButton = new JButton("Add");
            addButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    cardLayout.show(frame.getContentPane(), "ADD_PANEL");
                }
            });

            buttonPanel.add(addButton);

            // remove button, shows the "remove event panel" when pressed
            JButton removeButton = new JButton("Remove");
            removeButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    cardLayout.show(frame.getContentPane(), "REMOVAL_PANEL");
                }
            });

            buttonPanel.add(removeButton);


            // filter button, shows the "filter event panel" when pressed
            JButton filterButton = new JButton("Filter");
            filterButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    cardLayout.show(frame.getContentPane(), "FILTER_PANEL");
                }
            });

            buttonPanel.add(filterButton);

            return buttonPanel;
        }

        private void updateUI() {

            // this method is supposed to update the ui after a new event has been added/an old one removed
            // As of now, this method does not work
            // The best method to update the UI would be to create an entirely new panel and replace it with the old one

            for (int i = 0; i < weekdayPanels.size(); i++) {
                JScrollPane panel = weekdayPanels.get(i);
                ArrayList<Event> eventList = (ArrayList) handler.showEventsOnDay(weekdayList.get(i));
                for (int j = 0; j < eventList.size(); j++) {


                }
            }
            JPanel weekPanel = new JPanel();


            mainPanel.remove(weekPanel);
            mainPanel.add(this.weekPanel);
        }


    }

    // needs changes
    class WeekdayPanel {

        // supposed to represent the panels for each day

        private JScrollPane pane;
        private JPanel panel;
        private WeekDays day;
        private List<JLabel> eventLabelList;
        private BoxLayout layout;

        WeekdayPanel(String name, WeekDays day) {

            this.pane = new JScrollPane();
            this.panel = new JPanel();
            this.layout = new BoxLayout(pane, BoxLayout.Y_AXIS);
            pane.setLayout(new ScrollPaneLayout());
            this.day = day;
            this.eventLabelList = new ArrayList<>();

        }


        // creates the actual panel

        public JScrollPane createDayPanel() {

            ArrayList<Event> eventList = (ArrayList) handler.showEventsOnDay(day);
            for (int i = 0; i < eventList.size(); i++) {
                JLabel label = new JLabel("<html>" + eventList.get(i).toString() +"</html>");
                eventLabelList.add(label);
                panel.add(label);
            }

            pane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
            pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

            pane.add(panel);

            return pane;
        }

        // change
        public void addElementToList(String element) {

        }

        // change

        public void removeElementFromList(String element) {

        }

    }

    // fully working
    class addEventPanel {

        // creates panel where new event can be added

        JPanel addEventPanel;


        public JPanel createAddEventPanel() {

            // gridlayout does not need to be replaced for this panel, works fine
            addEventPanel = new JPanel(new GridLayout(8, 2));
            createComponents(addEventPanel);

            return addEventPanel;
        }

        // components for the panel

        private void createComponents(JPanel addEventPanel) {


            addEventPanel.add(new JLabel("Name: "));
            JTextField nameField = new JTextField();
            addEventPanel.add(nameField);

            addEventPanel.add(new JLabel("Start time:"));
            JTextField startField = new JTextField();
            addEventPanel.add(startField);

            addEventPanel.add(new JLabel("End time:"));
            JTextField endField = new JTextField();
            addEventPanel.add(endField);

            addEventPanel.add(new JLabel("Day:"));
            JTextField dayField = new JTextField();
            addEventPanel.add(dayField);

            addEventPanel.add(new JLabel("Teacher:"));
            JTextField teacherField = new JTextField();
            addEventPanel.add(teacherField);

            addEventPanel.add(new JLabel("Location:"));
            JTextField locationField = new JTextField();
            addEventPanel.add(locationField);

            JLabel errorLabel = new JLabel();
            addEventPanel.add(errorLabel);

            // button which adds the event to handler, gets data from textfields
            JButton addNewEventButton = new JButton("Add new event");
            addNewEventButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {
                        Lecture l = new Lecture(
                                nameField.getText().toString(),
                                Integer.parseInt(startField.getText().toString()),
                                Integer.parseInt(endField.getText().toString()),
                                dayField.getText().toString(),
                                teacherField.getText().toString(),
                                locationField.getText().toString()
                        );
                        handler.add(l);
                        mainPanel.updateUI();
                    } catch (Exception e1) {
                        // throws error if one of the textfields is empty
                        errorLabel.setText("Error");
                    }
                    errorLabel.setText("Succesfully added");
                    nameField.setText("");
                    startField.setText("");
                    endField.setText("");
                    dayField.setText("");
                    teacherField.setText("");
                    locationField.setText("");
                }
            });

            addEventPanel.add(addNewEventButton);

            addEventPanel.add(new JPanel(new GridLayout(1,1)).add(new JButton(new AbstractAction("Back") {
                @Override
                public void actionPerformed(ActionEvent e) {
                    cardLayout.show(frame.getContentPane(), "MAIN_PANEL");
                }
            })));

        }

    }


    // fully working, no changes needed
    class filterPanel {

        JPanel filterPanel;
        JTextField stringField;
        List<Event> events;
        JLabel resultsLabel;

        // filter panel

        private JPanel createFilterPanel() {

            filterPanel = new JPanel(new GridLayout(3,2));
            filterPanel.add(new JLabel("Enter string to search for:"));
            stringField = new JTextField();

            filterPanel.add(stringField);

            events = new ArrayList<>();

            events = handler.eventsWhichComplyWith(new ContainsWord(stringField.getText().toString()));

            filterPanel.add(new JLabel("Results:"));

            resultsLabel = new JLabel();
            filterPanel.add(resultsLabel);




            filterPanel.add(new JButton(new AbstractAction("Back") {
                @Override
                public void actionPerformed(ActionEvent e) {
                    cardLayout.show(frame.getContentPane(), "MAIN_PANEL");
                    resultsLabel.setText("");
                    stringField.setText("");
                }
            }));

            filterPanel.add(new JButton(new AbstractAction("Search") {
                @Override
                public void actionPerformed(ActionEvent actionEvent) {

                    events = handler.eventsWhichComplyWith(new ContainsWord(stringField.getText().toString()));

                    String s = "";

                    for (Object event : events) {
                        s += event.toString() + "\n";
                    }

                    resultsLabel.setText("<html>" + s + "</html>");

                }
            }));



            return filterPanel;


        }

        // panel where results will be displayed

        private JPanel searchResultsPanel() {

            JPanel searchResultsPanel = new JPanel(new GridLayout(1,2));

            searchResultsPanel.add(new JButton(new AbstractAction("Back") {
                @Override
                public void actionPerformed(ActionEvent e) {
                    cardLayout.show(frame.getContentPane(), "MAIN_PANEL");
                }
            }));

            searchResultsPanel.add(new JButton(new AbstractAction("Search") {
                @Override
                public void actionPerformed(ActionEvent actionEvent) {

                }
            }));

            return searchResultsPanel;
        }
    }


    // fully working
    class removePanel {

        private JPanel removePanel;

        private JPanel createRemovePanel() {
            removePanel = new JPanel(new GridLayout(3,2));
            removePanel.add(new JLabel("<html>Type name of the lesson you want to remove:</html>"));
            JTextField removalField = new JTextField();
            removePanel.add(removalField);

            JLabel errorLabel = new JLabel("");
            JLabel lessonsRemovedLabel = new JLabel("");

            removePanel.add(errorLabel);
            removePanel.add(lessonsRemovedLabel);

            removePanel.add(new JButton(new AbstractAction("Back") {
                @Override
                public void actionPerformed(ActionEvent e) {
                    cardLayout.show(frame.getContentPane(), "MAIN_PANEL");
                    errorLabel.setText("");
                    removalField.setText("");
                    lessonsRemovedLabel.setText("");
                }
            }));

            removePanel.add(new JButton(new AbstractAction("Remove") {
                @Override
                public void actionPerformed(ActionEvent e) {
                    ArrayList<Event> removalList = (ArrayList<Event>) handler.eventsWhichComplyWith(new ContainsWord(removalField.getText().toString()));
                    for (Event event : removalList) {
                        handler.remove(event);
                    }
                    if (removalList.size() == 1) {
                        errorLabel.setText("<html>" + removalList.size() + " event was succesfully removed</html>");
                    } else {
                        errorLabel.setText("<html>" + removalList.size() + " events were succesfully removed</html>");
                    }

                    String s = "";
                    for (Event event : removalList) {
                        s += event.toString() +"\n";
                    }
                    lessonsRemovedLabel.setText("<html>" + s + "</html>");
                }
            }));


            return removePanel;
        }
    }

}